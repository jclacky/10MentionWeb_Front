
## The designs were created to the following widths:

- Mobile: >= 576px
- Desktop: >= 1400px

### Typography

# Headings, Call-to-actions, Header Navigation

- Family: [Raleway](https://fonts.google.com/specimen/Raleway)
- Weights: 400, 700

# Body

- Family: [Open Sans](https://fonts.google.com/specimen/Open+Sans)
- Weights: 400 */

## les couleurs (variable) : 
Very-dark-blue: hsl(243, 87%, 12%);
Desaturated-Blue: hsl(238, 22%, 44%);
Bright-blue: hsl(224, 93%, 58%);
Moderate-cyan: hsl(170, 45%, 43%);
Light-grayish-blue: hsl(240, 75%, 98%);
Light-gray: hsl(0, 0%, 75%);
